/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author enrique.ignacioamorin
 */
public abstract class MathCard  extends Card {
    
    protected int operator1;
    protected int operator2;
    protected char operation;
    
    public final static char SUB = '-';
    public final static char SUM = '+';
    public final static char MULT = '*';

    public MathCard(int operator1, int operator2, char operation, String text) {
        super(text);
        this.operator1 = operator1;
        this.operator2 = operator2;
        this.operation = operation;
    }
    
    
    
}
